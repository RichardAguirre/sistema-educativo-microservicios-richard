package com.educativo.asignaturas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsignaturasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AsignaturasApplication.class, args);
	}

}
